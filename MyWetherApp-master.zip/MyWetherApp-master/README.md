# MyWetherApp
A Simple Wether App for Android    

Just Enter Your City and Find out the current Wether of your city and also you can get the latitude and longitude of your location

The wether data is used from the openwethermap api
a simple interface to display the temp,humidity 
